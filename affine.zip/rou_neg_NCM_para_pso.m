function error=rou_neg_NCM_para_pso(SOH,rou_neg_new,para,a,b,c,d,start_point,over_point)
% start_point=100;over_point=150;
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
rou_neg_est = x1.*(a.*exp(b.*(x2.*SOH(start_point:over_point)+x3))+c.*exp(d.*(x2.*SOH(start_point:over_point)+x3)))+x4;
error=rms(rou_neg_new(start_point:over_point)-rou_neg_est);
end