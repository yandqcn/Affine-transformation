function error=Dsneg_NCM_para_pso(SOH,Dsneg_new,para,a,b,c,start_point,over_point)
% start_point=75;over_point=130;
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
Dsneg_est=x1.*(a.*(x2.*SOH(start_point:over_point)+x3).^b+c)+x4;
error=rms(Dsneg_new(start_point:over_point)-Dsneg_est);
if ~isreal(error)
    error=1e4;
end