function error=x100_NCM_para_pso(SOH,x100,para,a,b,c,start_point,over_point)
% start_point=1;over_point=125;
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
x100_est=x1.*(a.*(x2.*SOH(start_point:over_point)).^(b+x3)+c)+x4;
error=rms(x100(start_point:over_point)'-x100_est);
if isreal(x100_est)==0
    error=10000;
end
end