cycle=350;    %循环数
x0=zeros(cycle,1);
x100=zeros(cycle,1);
y0=zeros(cycle,1);
y100=zeros(cycle,1);
cycle_ocv = length(x0set);
Dsneg_yuan=[Dsneg_new(Dsneg_new~=0)];
kappa_yuan=[kappa_new(kappa_new~=0)];
rou_neg_yuan=[rou_neg_new(rou_neg_new~=0)];

Dsneg_new=zeros(1,cycle);
kappa_new=zeros(1,cycle);
rou_neg_new=zeros(1,cycle);
for i=1:cycle    
    Dsneg_new(i)=interp1((1:1:cycle_ocv)',Dsneg_yuan,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
    kappa_new(i)=interp1((1:1:cycle_ocv)',kappa_yuan,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
    rou_neg_new(i)=interp1((1:1:cycle_ocv)',rou_neg_yuan,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
end
Dsneg_new_1=Dsneg_new./Dsneg_new(1);%归一化
kappa_new_1=kappa_new./kappa_new(1);
rou_neg_new_1=rou_neg_new./rou_neg_new(1);
for i=1:cycle
    x0(i)=interp1((1:1:cycle_ocv)',x0set,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
    x100(i)=interp1((1:1:cycle_ocv)',x100set,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
    y0(i)=interp1((1:1:cycle_ocv)',y0set,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
    y100(i)=interp1((1:1:cycle_ocv)',y100set,1+(i-1)*(cycle_ocv-1)/(cycle-1),'pchip');
end
cyc=(1:cycle)/200;
%%
a=0.0199;b=-0.0218;c=6.6992e-05;d=1.7613;
LB=[0.3,0.1,-1,-0.02];
UB=[1.2,0.6,1,0.02];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',100,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',150);
[para,error]=particleswarm(@(para)x0_NCM_para_pso(cyc,x0,para,a,b,c,d,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
x0_est = x1.*(a.*exp(b.*(x2.*cyc+x3))+c.*exp(d.*(x2.*cyc+x3)))+x4;
figure
plot(x0)
hold on
plot(x0_est)
legend('原始','预测')
title('x0')
%%
%x100
a=0.0426;b=0.8759;c=0.8007;
LB=[0.6,0.9,-1,-1];
UB=[3,4,1,1];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',100,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',150);
[para,error]=particleswarm(@(para)x100_NCM_para_pso(cyc,x100,para,a,b,c,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
% x100_est=x1.*(a.*(x2.*cyc+x3).^b+c)+x4;
x100_est=x1.*(a.*(x2.*cyc).^(b+x3)+c)+x4;
figure
plot(x100)
hold on
plot(x100_est)
legend('原始','预测')
title('x100')
%%
%y0
a=0.0206;b=-2.6141;c=0.8376;d=-0.0080;
LB=[0.8,0,-0.2,-0.05];
UB=[1.2,3,1,0.02];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',150,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',150);
[para,error]=particleswarm(@(para)y0_NCM_para_pso(cyc,y0,para,a,b,c,d,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
y0_est = x1.*(a.*exp(b.*(x2.*cyc+x3))+c.*exp(d.*(x2.*cyc+x3)))+x4;
figure
plot(y0)
hold on
plot(y0_est)
legend('原始','预测')
title('y0')
%%
%y100
a=0.1855;b=0.0013;c=1.3428e-04;d=3.8848;
LB=[0.1,0.2,0,-0.002];
UB=[0.3,1.2,1,0.2];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',200,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',300);
[para,error]=particleswarm(@(para)y100_NCM_para_pso(cyc,y100,para,a,b,c,d,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
y100_est = x1.*(a.*exp(b.*(x2.*cyc+x3))+c.*exp(d.*(x2.*cyc+x3)))+x4;
figure
plot(y100)
hold on
plot(y100_est)
legend('原始','预测')
title('y100')
%%
%Dsneg
a=-1.5919;b=0.2410;c=1.6423;
LB=[0,0,0,-0.5];
UB=[0.2,10,1,0.5];
% LB=[0,0,0,-1];
% UB=[5,2,1,0.5];
start_point=50;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',150,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',300);
[para,error]=particleswarm(@(para)Dsneg_NCM_para_pso(cyc,Dsneg_new_1,para,a,b,c,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
Dsneg_est=x1.*(a.*(x2.*cyc+x3).^b+c)+x4;
Dsneg_est = Dsneg_est.*Dsneg_new(1);
figure
plot(Dsneg_new(1:end))
hold on
plot(Dsneg_est(1:end))
legend('原始','预测')
%%
%kappa
a=0.6065;b=-10.2616;c=0.4439;d=-0.6253;
LB=[0,0,0,0];
UB=[5,5,1.5,3];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',60,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',300);
[para,error]=particleswarm(@(para)kappa_NCM_para_pso(cyc,kappa_new_1,para,a,b,c,d,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
kappa_est = x1.*(a.*exp(b.*(x2.*cyc+x3))+c.*exp(d.*(x2.*cyc+x3)))+x4;
kappa_est = kappa_est.*kappa_new(1);
figure
plot(kappa_new)
hold on
plot(kappa_est)
legend('原始','预测')
title('kappa')
%%
%rou_neg
a=8.9144;b=0.2963;c=-8.1937;d=-6.0054;
LB=[0.001,0.07,-0.1,-3];
UB=[0.004,0.085,1,1.5];
start_point=1;
over_point=125;
options = optimoptions('particleswarm','SwarmSize',200,'HybridFcn',@fmincon,'PlotFcn','pswplotbestf','UseParallel',false,'MaxIterations',150);
[para,error]=particleswarm(@(para)rou_neg_NCM_para_pso(cyc,rou_neg_new,para,a,b,c,d,start_point,over_point),4,LB,UB,options);
x1=para(1);x2=para(2);x3=para(3);x4=para(4);
rou_neg_est = x1.*(a.*exp(b.*(x2.*cyc+x3))+c.*exp(d.*(x2.*cyc+x3)))+x4;
% rou_neg_est = rou_neg_est.*rou_neg_new(1);
figure
plot(rou_neg_new)
hold on
plot(rou_neg_est)
legend('原始','预测')
title('rouneg')